#include <stdexcept>

#include "byte_stream.hh"

ByteStream::ByteStream( uint64_t capacity )
  : capacity_( capacity ), buffer_(), closed_( false ), error_( false ), bytes_pushed_( 0 ), bytes_popped_( 0 )
{}

void Writer::push( std::string_view data )
{
  if ( closed_ || error_ || buffer_.size() >= capacity_ ) {
    return;
  }
  // Your code here.
  // (void)data;
  uint64_t remaining_capacity = capacity_ - buffer_.size();
  uint64_t pushed_size = std::min( remaining_capacity, data.size() );
  /*for (uint64_t i = 0; i < pushed_size; i++){

    buffer_.push_back(data[i]);
  }*/

  buffer_.insert( buffer_.end(), data.begin(), data.begin() + pushed_size );
  bytes_pushed_ += pushed_size;
}

void Writer::close()
{

  // Your code here.
  closed_ = true;
}

void Writer::set_error()
{
  // Your code here.
  error_ = true;
}

bool Writer::is_closed() const
{
  // Your code here.
  return closed_;
}

uint64_t Writer::available_capacity() const
{
  // Your code here.
  return capacity_ - buffer_.size();
}

uint64_t Writer::bytes_pushed() const
{
  // Your code here.
  return bytes_pushed_;
}

std::string_view Reader::peek() const
{
  // Your code here.
  if ( buffer_.empty() ) {

    return std::string_view();
  }
  return std::string_view( buffer_.data(), buffer_.size() );
}

bool Reader::is_finished() const
{
  // Your code here.
  return closed_ && ( bytes_popped_ == bytes_pushed_ );
}

bool Reader::has_error() const
{
  // Your code here.
  return error_;
}

void Reader::pop( uint64_t len )
{
  if ( len > buffer_.size() ) {
    error_ = true;
    return;
  }
  // Your code here.
  //(void)len;
  /*for (uint64_t number = 0; number < len; number++){
    buffer_.pop();
  }*/
  buffer_.erase( buffer_.begin(), buffer_.begin() + len );
  bytes_popped_ += len;
}

uint64_t Reader::bytes_buffered() const
{
  // Your code here.
  return buffer_.size();
}

uint64_t Reader::bytes_popped() const
{
  // Your code here.
  return bytes_popped_;
}
